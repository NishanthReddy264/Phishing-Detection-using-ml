from flask import Flask, request, jsonify
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import VotingClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectFromModel
import pandas as pd
import numpy as np
from flask_cors import CORS

app = Flask(__name__, template_folder='.')
CORS(app)
# Load your dataset
dataset = pd.read_csv('dataset.csv')

# Separate features and target variable
X = dataset.iloc[:, :-1]  # Features (all columns except the last one)
y = dataset.iloc[:, -1]   # Target variable (the last column)

# Feature selection using SelectFromModel
# Choose a base estimator for feature selection (e.g., L1 regularized Logistic Regression)
selector = SelectFromModel(LogisticRegression(max_iter=10000, solver='liblinear', penalty='l1'))
X_selected = selector.fit_transform(X, y)

# Scale the input features
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X_selected)

# Initialize the individual classifiers
lr = LogisticRegression(max_iter=10000, solver='lbfgs')
svc = SVC()  # Set probability=True for SVC to enable probability estimates
dt = DecisionTreeClassifier()

# Create a voting classifier combining LR, SVC, and DT with hard voting
voting_clf = VotingClassifier(estimators=[('lr', lr), ('svc', svc), ('dt', dt)], voting='hard')

# Fit the voting classifier on the full dataset
voting_clf.fit(X_scaled, y)

@app.route('/predict', methods=['POST'])
def predict():
    features_str = request.form['features']
    features = list(map(float, features_str.split(',')))
    X_selected_input = selector.transform([features])
    X_scaled_input = scaler.transform(X_selected_input)
    prediction = voting_clf.predict(X_scaled_input)[0]
    temp="phishing";
    if int(prediction)==1:
        temp="Legitimate";
    elif int(prediction)!=1:
        temp="Phishing";
    return jsonify({'prediction': temp})

if __name__ == '__main__':
    app.run(debug=True)
