chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'classifyPhishing') {
    const features = request.features.split(',');
    // Send the features to content script for processing
    chrome.tabs.query({ active: true, currentWindow: true }, function (tabs) {
      chrome.tabs.sendMessage(tabs[0].id, { action: 'classifyPhishing', features: features }, function (response) {
        sendResponse(response);
      });
    });
    return true;
  }
});
