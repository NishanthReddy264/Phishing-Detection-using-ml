chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.action === 'classifyPhishing') {
    const X_input = request.features;//.map(Number); // Convert string features to numbers
    // Perform the same feature selection and scaling as in the original code
    //const X_selected_input = selector.transform([X_input]);
    //const X_scaled_input = scaler.transform(X_selected_input);
    // Make prediction using the voting classifier
    const prediction = voting_clf.predict(X_input);
    sendResponse({ prediction: prediction });
  }
});
