document.addEventListener('DOMContentLoaded', function () {
document.getElementById('classifyButton').addEventListener('click', function () {
  const features = document.getElementById('features').value.trim();
  if (features !== '') {
    fetch('http://localhost:5000/predict', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: 'features=' + encodeURIComponent(features),
    })
      .then(response => response.json())
      .then(data => {
        document.getElementById('result').innerText = 'Prediction: ' + data.prediction;
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }
});
});