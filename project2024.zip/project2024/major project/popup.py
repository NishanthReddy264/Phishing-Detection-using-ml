import requests
from bs4 import BeautifulSoup

def is_phishing(url):
    try:
        response = requests.get(url)
        soup = BeautifulSoup(response.text, 'html.parser')
        # Check if there are any text fields within popup windows
        popup_windows = soup.find_all('div', {'class': 'popup'})  # Example class name, adjust as needed
        for window in popup_windows:
            text_fields = window.find_all('input', {'type': 'text'})  # Example input type for text field
            if text_fields:
                return True  # Phishing detected if a popup window contains a text field
        return False  # No phishing detected
    except Exception as e:
        print("An error occurred:", e)
        return None  # Unable to determine due to an error

# Example usage:
url = "https://shadetreetechnology.com/V4/validation/a111aedc8ae390eabcfa130e041a10a4"  # Replace with your URL
result = is_phishing(url)
if result is None:
    print("Unable to determine due to an error.")
elif result:
    print("Phishing detected!")
else:
    print("Legitimate.")
