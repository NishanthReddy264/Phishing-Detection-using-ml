from flask import Flask, request, jsonify, render_template
from sklearn.model_selection import train_test_split, StratifiedKFold
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import VotingClassifier
from sklearn.metrics import accuracy_score
from sklearn.preprocessing import StandardScaler
from sklearn.feature_selection import SelectFromModel
import pandas as pd
import numpy as np

app = Flask(__name__, template_folder='.')


# Load your dataset
dataset = pd.read_csv('PhishingDataset.csv')

# Separate features and target variable
X = dataset.iloc[:, :-1]  # Features (all columns except the last one)
y = dataset.iloc[:, -1]   # Target variable (the last column)
feature_names = X.columns  # Get feature names

# Feature selection using SelectFromModel
# Choose a base estimator for feature selection (e.g., L1 regularized Logistic Regression)
# Modify the threshold to ensure SSLfinal_State is always selected
selector = SelectFromModel(LogisticRegression(max_iter=10000, solver='liblinear', penalty='l1'), threshold=-np.inf)
X_selected = selector.fit_transform(X, y)

# Manually ensure SSLfinal_State is selected
ssl_index = feature_names.get_loc("SSLfinal_State")
X_selected[:, ssl_index] = X.iloc[:, ssl_index]

# Set feature names for SelectFromModel instance
selector.get_support(indices=True)
selected_feature_names = feature_names[selector.get_support()]

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_selected, y, test_size=0.2, random_state=42)

# Scale the input features
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_test_scaled = scaler.transform(X_test)

# Initialize the individual classifiers
lr = LogisticRegression(max_iter=10000, solver='lbfgs')
svc = SVC()  # Set probability=True for SVC to enable probability estimates
dt = DecisionTreeClassifier()

# Create a voting classifier combining LR, SVC, and DT with hard voting
voting_clf = VotingClassifier(estimators=[('lr', lr), ('svc', svc), ('dt', dt)], voting='hard')

# Define cross-validation strategy
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

# Fit the voting classifier without grid search
voting_clf.fit(X_train_scaled, y_train)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    url_features = data['url_features']
    
    # Convert features to numpy array and reshape
    url_features = np.array(url_features, dtype=float).reshape(1, -1)
    
    # Manually ensure SSLfinal_State is selected
    url_features[:, ssl_index] = url_features[:, ssl_index]
    
    # Scale the input features
    url_features_scaled = scaler.transform(url_features)
    
    # Make predictions
    prediction = voting_clf.predict(url_features_scaled)
    
    # Return the prediction
    return jsonify({'prediction': int(prediction[0])})

if __name__ == '__main__':
    app.run(debug=True)
