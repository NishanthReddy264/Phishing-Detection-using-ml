chrome.runtime.onInstalled.addListener(function() {
  console.log('Extension installed');
});

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.contentScriptQuery == 'fetchURL') {
    chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
      var currentTab = tabs[0];
      sendResponse({ url: currentTab.url });
    });
    return true;
  }
});
