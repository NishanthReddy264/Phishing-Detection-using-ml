document.addEventListener('DOMContentLoaded', function() {
  chrome.runtime.sendMessage({ contentScriptQuery: 'fetchURL' }, function(response) {
    var url = response.url;
    fetchPrediction(url);
  });
});

function fetchPrediction(url) {
  fetch('http://localhost:5000/predict', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: `features=${encodeURIComponent(url)}`,
  })
  .then(response => response.json())
  .then(data => {
    displayPrediction(data.prediction);
  })
  .catch(error => {
    console.error('Error:', error);
    displayPrediction('Error');
  });
}

function displayPrediction(prediction) {
  var predictionElement = document.getElementById('prediction');
  predictionElement.textContent = `Prediction: ${prediction}`;
}
